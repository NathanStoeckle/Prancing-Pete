// sound.js
"use strict";
// if app exists use the existing copy
// else create a new object literal
var app = app || {};

// define the .sound module and immediately invoke it in an IIFE
app.sound = (function(){
	//console.log("sound.js module loaded");
	var bgAudio = undefined;
	var soundFx = undefined;
	var currentEffect = 0;
	var currentDirection = 1;
	var effectSounds = [];	

	function init(){
		bgAudio = document.querySelector("#bgAudio");
		bgAudio.volume=0.25;
		soundFx = document.querySelector("#soundFx");
		bgAudio.loop = true;
	}

	function changeLevel(level) {
		if (level === 1){
			bgAudio.src = "media/Level1.mp3";
			bgAudio.loop = true;
			//bgAudio.play();
		}
		else if(level === 2) {
			bgAudio.src = "media/Level2.mp3";
			bgAudio.loop = true;
			//bgAudio.play();
		}
		else {
			bgAudio.src = "media/Level3.mp3";
			bgAudio.loop = true;
			//bgAudio.play();
		}
		bgAudio.play();
	}

	function playBGAudio(){
		bgAudio.play();
	}

	function stopBGAudio(){
		bgAudio.pause();
		bgAudio.currentTime = 0;
	}

	function playEffect(){
    	soundFx.volume = 0.3;
		soundFx.play();
	}

	// export a public interface to this module
	// TODO
  return {
    init: init,
    stopBGAudio: stopBGAudio,
    playEffect: playEffect,
    playBGAudio: playBGAudio,
    changeLevel: changeLevel
  };
}());