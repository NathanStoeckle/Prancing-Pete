"use strict";

class GameObject {
    constructor(height, width, x, y) {
        this.height = height;
        this.width = width;
        this.image = new Image();
        this.x = x;
        this.y = y;
    }

    draw(ctx) {
        ctx.drawImage(this.image, this.x, this.y);
    }

    update(x, y, image) {
        this.image = image ? image : this.image;
        this.x = x;
        this.y = y;
    }
}