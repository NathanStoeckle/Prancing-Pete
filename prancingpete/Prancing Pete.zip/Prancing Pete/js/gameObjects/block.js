"use strict";

class Block extends GameObject {
    constructor(x, y) {
        super(10, 10, x, y);
        this.image.src = "images/box.png";
    }

    draw(ctx){
        super.draw(ctx);
    }

    update(x, y, image){
        super.update(x, y, image);
    }
}