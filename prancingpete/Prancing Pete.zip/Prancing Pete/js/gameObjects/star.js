"use strict";

class Star extends GameObject {
    constructor(height, width, x, y) {
        super(height, width, x, y);
        this.image.src = "images/star.png";
    }

    draw(ctx){
        super.draw(ctx);
    }

    update(x, y){
        super.update(x, y, this.image);
    }
}