"use strict";

class Pete extends GameObject {
    constructor(height, width, x, y) {
        super(height, width, x, y);
        this.image.src = "images/spriteIdle.png";
        this.speed = 3;
        this.velocityX = 0;
        this.velocityY = 0;
        this.isJumping = false;
        this.isGrounded = false;
        this.frameChange = 0;
    }

    draw(ctx){
        super.draw(ctx);
    }

    update(x, y){
        this.image.src = this.velocityX ? "images/spriteWalk.png" : this.image.src;
        this.image.src = this.isJumping ? "images/spriteJump.png" : this.image.src;
        super.update(x, y, this.image);
    }
}