"use strict";

var app = app || {};

app.levelFactory = (function () {

    // We use buildBox to encapsulate batch creation of blocks. We use the spread operator to add them to the larger levelObjects array.
    function buildBox(myX, width, myY, height) {
        var boxes = [];
        for (var x = myX; x < myX + width; x += 10) {
            for (var y = myY; y < myY + height; y += 10) {
                boxes.push(new Block(x, y));
            }
        }

        return boxes;
    }

    function createLevel(level) {
        let levelObjects = [];
        // create level boundaries

        for (var i = 0; i < height; i += 10) {
            levelObjects.push(new Block(0, i));
        }

        for (var i = 0; i < height; i += 10) {
            levelObjects.push(new Block(width - 10, i));
        }

        for (var i = 0; i < width; i += 10) {
            levelObjects.push(new Block(i, height - 5));
        }

        switch (currentLevel) {
            case (1):
                levelObjects.push(...buildBox(120, 70, 150, 50));
                levelObjects.push(...buildBox(270, 70, 120, 50));
                levelObjects.push(...buildBox(400, 70, 80, 50));
                levelObjects.push(new Star(10, 10, 425, 70));
                break;

            case (2):
                //LEVEL 2 SETUP
                //  This level should be slighty more difficult
                levelObjects.push(...buildBox(120, 70, 150, 50));
                levelObjects.push(...buildBox(260, 70, 100, 50));
                levelObjects.push(...buildBox(120, 65, 50, 50));
                levelObjects.push(...buildBox(260, 50, 30, 25));
                levelObjects.push(...buildBox(380, 50, 30, 25));
                levelObjects.push(...buildBox(400, 75, 30, 200));
                levelObjects.push(new Star(10, 10, 480, height - 14));
                break;

            case (3):
                //LEVEL 3
                //  This should be the hardest level
                levelObjects.push(...buildBox(120, 35, 180, 25));
                //Next box to jump upon
                levelObjects.push(...buildBox(230, 55, 135, 30));
                //A mini series of boxes to jump on - they start to become smaller
                levelObjects.push(...buildBox(360, 50, 135, 10));
                levelObjects.push(...buildBox(420, 40, 100, 10));
                levelObjects.push(...buildBox(380, 30, 70, 10));
                levelObjects.push(...buildBox(420, 20, 40, 10));
                levelObjects.push(...buildBox(400, 10, 20, 10));
                levelObjects.push(...buildBox(265, 25, 60, 15));
                levelObjects.push(...buildBox(180, 15, 70, 20));
                levelObjects.push(...buildBox(80, 15, 55, 15));
                //The end block
                levelObjects.push(...buildBox(30, 15, 30, 170));

                levelObjects.push(new Star(10, 10, 15, height - 15));
                break;
        }

        return levelObjects;
    }

    return {
        createLevel: createLevel
    }
})();