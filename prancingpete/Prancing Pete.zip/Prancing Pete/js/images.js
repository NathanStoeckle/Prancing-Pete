"use strict";

var app = app || {};

app.IMAGES = {
    bgImage: "images/background.jpg",
    spriteIdle: "images/spriteIdle.png", 
    spriteWalk: "images/spriteWalk.png",
    spriteJump: "images/spriteJump.png",
    box: "images/box.png",
    trophyStar: "images/star.png"
};