// timer.js
"use strict";
// if app exists use the existing copy
// else create a new object literal
var app = app || {};

app.timer = (function(){
    var seconds = 30;
    var milliSeconds = 100;

    var interval = setInterval(function() {
        if(!paused && isPlaying)
        {            
            milliSeconds -= 9;
            if(milliSeconds <= 1) { seconds--; milliSeconds = 99 };
            if(seconds <= 0) { milliSeconds = 0 }
        }
    }, 100);

    function resetTimer(){
        seconds = 30;
        milliSeconds = 100;
    }
    
    function getExpiredSeconds() {
        return 30 - seconds;
    }

    function getTimerString() {
        return seconds + ":" + milliSeconds;;
    }

    function isTimeUp() {
        return seconds <= 0;
    }

    return {
        getExpiredSeconds: getExpiredSeconds,
        getTimerString: getTimerString,
        resetTimer: resetTimer,
        isTimeUp: isTimeUp
    }

})();