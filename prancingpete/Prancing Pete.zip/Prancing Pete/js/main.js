"use strict";

var app = app || {};
    
var canvas = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");
    var width = 500;
    var height = 200;
    var keys = [];
    var friction = 0.8;
    var gravity = 0.3;
    var paused = false;
    var isPlaying = false;
    var animationID = 0;

var boxes = [];
var trophy = {};
var currentLevel = 1;
let player = new Pete(10, 10, (width / 10), (height - 15));
var timer = '';
var totalTime = 0;

function update() {

    let levelObjects = app.levelFactory.createLevel(currentLevel);    

    // check keys
    if (keys[38] || keys[32] || keys[87]) {
        // up arrow or space
        if (!player.isJumping && player.isGrounded) {
            player.isJumping = true;
            app.sound.playEffect();
            player.isGrounded = false;
            player.velocityY = -player.speed * 2;
        }
    }
    if (keys[39] || keys[68]) {
        // right arrow
        if (player.velocityX < player.speed) {
            player.velocityX++;
        }
    }
    if (keys[37] || keys[65]) {
        // left arrow
        if (player.velocityX > -player.speed) {
            player.velocityX--;
        }
    }    

    player.velocityX *= friction;
    player.velocityY += gravity;

    ctx.clearRect(0, 0, width, height);

    player.isGrounded = false;
    for (var i = 0; i < levelObjects.length; i++) {
        levelObjects[i].draw(ctx);

        var dir = colCheck(player, levelObjects[i]);

        if (dir === "l" || dir === "r") {
            player.velocityX = 0;
            player.isJumping = false;
        } else if (dir === "b") {
            player.isGrounded = true;
            player.isJumping = false;
        } else if (dir === "t") {
            player.velocityY *= -1;
        }
        else if(dir === "s") {
            currentLevel++;
            app.sound.changeLevel(currentLevel);
            totalTime += app.timer.getExpiredSeconds();
            app.timer.resetTimer();
            player.update(width / 10, height - 15);
            player.isGrounded = false;
            player.isJumping = false;
        }
    }

    if (player.isGrounded) {
        player.velocityY = 0;
    }

    player.x += player.velocityX;
    player.y += player.velocityY;

    player.update(player.x, player.y);
    player.draw(ctx);

    ctx.save();
    ctx.font = "25px Open Sans";
    ctx.fillText(app.timer.getTimerString(), width - 100, 25);
    ctx.restore();

    if(app.timer.isTimeUp()) {
        requestAnimationFrame(updateGameOver);
    }
    else if(currentLevel > 3) {
        requestAnimationFrame(updateWin);
    } else {
        animationID = requestAnimationFrame(update);
    }
}

function colCheck(shapeA, shapeB) {
    // get the vectors to check against
    var vX = (shapeA.x + (shapeA.width / 2)) - (shapeB.x + (shapeB.width / 2)),
        vY = (shapeA.y + (shapeA.height / 2)) - (shapeB.y + (shapeB.height / 2)),
        // add the half widths and half heights of the objects
        hWidths = (shapeA.width / 2) + (shapeB.width / 2),
        hHeights = (shapeA.height / 2) + (shapeB.height / 2),
        colDir = null;

    // if the x and y vector are less than the half width or half height, they we must be inside the object, causing a collision
    if (Math.abs(vX) < hWidths && Math.abs(vY) < hHeights) {
        // figures out on which side we are colliding (top, bottom, left, or right)
        var oX = hWidths - Math.abs(vX),
            oY = hHeights - Math.abs(vY);
        if (oX >= oY) {
            if (vY > 0) {
                colDir = "t";
                shapeA.y += oY;
            } else {
                colDir = "b";
                shapeA.y -= oY;
            }
        } else {
            if (vX > 0) {
                colDir = "l";
                shapeA.x += oX;
            } else {
                colDir = "r";
                shapeA.x -= oX;
            }
        }
    }

    if(colDir && shapeB instanceof Star) {
        colDir = "s";
    }

    return colDir;
}

document.body.addEventListener("keydown", function (e) {
    keys[e.keyCode] = true;

    if(e.keyCode === 80) {
        if(!paused) {
            pauseGame();
        }
        else {
            resumeGame();
        }
    }
});

document.body.addEventListener("keyup", function (e) {
    keys[e.keyCode] = false;
});

window.addEventListener("load", function () {
    //update();
    updateMain();
    //updateLevelSelect();
    //updateGameOver();
});

let enter = new Image();
enter.src = "images/enterKey.png";

let isShowing = false;
var blinkInterval = setInterval(function() {
    isShowing = !isShowing;
}, 500);

function updateMain() {
    if (keys[13]) {
        requestAnimationFrame(updateLevelSelect);
    } else {
        ctx.clearRect(0, 0, width, height);
        ctx.font = "50px Rakoon Personal Use Regular";
        ctx.fillText("Press Enter to Start!", (width/2) - 225, height/2);
        ctx.beginPath();
        ctx.fillStyle = "black";
        if(isShowing){
            ctx.fillRect((width/2) - 55, (height/2) + 15, 110, 60);
        }
        
        ctx.drawImage(enter, (width/2) - 50, (height/2) + 20, 100, 50);
        requestAnimationFrame(updateMain);
    }
}

function updateLevelSelect() {
    clearInterval(blinkInterval);
    if (keys[49]) {
        player.update((width / 10), (height - 15));
        currentLevel = 1;
        app.sound.changeLevel(currentLevel);
        app.timer.resetTimer();
        isPlaying = true;
        requestAnimationFrame(update);
    } else if(keys[50]) {
        currentLevel = 2;
        app.sound.changeLevel(currentLevel);
        player.update((width / 10), (height - 15));
        app.timer.resetTimer();
        isPlaying = true;
        requestAnimationFrame(update);
    } else if(keys[51]) {
        currentLevel = 3;
        app.sound.changeLevel(currentLevel);
        player.update((width / 10), (height - 15));
        app.timer.resetTimer();
        isPlaying = true;
        requestAnimationFrame(update);
    } else {
        ctx.clearRect(0, 0, width, height);
        for(var i = 1; i < 4; i++) {        
            ctx.fillStyle = "black";
            ctx.fillRect((i * 120) - 5, 120, 60, 60);
            ctx.save();
            ctx.fillStyle = "#0066ff";
            ctx.fillRect(i * 120, 125, 50, 50);
            ctx.restore();
            ctx.font = "30px Tiny Box BlackBitA8 Regular";
            ctx.save();
            ctx.fillStyle = "white";
            ctx.fillText(i, i * 123, 175, 50, 50);
            ctx.restore();
            ctx.font = "35px Tiny Box BlackBitA8 Regular";
            ctx.fillText("Type Level #!", (width/2) - 180, height/2);
        }
                
        requestAnimationFrame(updateLevelSelect);
    }
}

function updateWin() {
    if (keys[13]) {
        isPlaying = false;
        requestAnimationFrame(updateLevelSelect);
    }
    else {
        ctx.clearRect(0, 0, width, height);
        ctx.fillStyle = "black";
        ctx.fillRect(0, 0, width, height);
        ctx.save();
        ctx.font = "35px Tiny Box BlackBitA8 Regular";
        ctx.fillStyle = "white";
        ctx.fillText("GAME OVER", (width/2) - 100, 50);
        ctx.save();
        ctx.font = "25px Tiny Box BlackBitA8 Regular";
        ctx.fillText("Completed in: " + totalTime + " seconds!", (width/2) - 120, 75);
        ctx.save();
        ctx.font = "25px Open Sans";
        ctx.fillText("PRESS ENTER TO PLAY AGAIN", (width/2) - 165, height/2 + 50);
        ctx.restore();
        ctx.restore();
        ctx.restore();
        requestAnimationFrame(updateWin);
    }
}

function updateGameOver() {
    if (keys[13]) {
        isPlaying = false;
        requestAnimationFrame(updateLevelSelect);
    }
    else {
        ctx.clearRect(0, 0, width, height);
        ctx.fillStyle = "black";
        ctx.fillRect(0, 0, width, height);
        ctx.save();
        ctx.font = "35px Tiny Box BlackBitA8 Regular";
        ctx.fillStyle = "white";
        ctx.fillText("GAME OVER", (width/2) - 100, 50);
        ctx.save();
        ctx.font = "25px Open Sans";
        ctx.fillText("PRESS ENTER TO PLAY AGAIN", (width/2) - 165, height/2 + 50);
        ctx.restore();
        ctx.restore();
        ctx.restore();
        requestAnimationFrame(updateGameOver);
    }
}

function pauseGame() {
    paused = true;

    ctx.font = "40px Tiny Box BlackBitA8 Regular";
    ctx.fillStyle = "white";
    ctx.fillText("--PAUSED--", (width/2) - 190, height/2);
    
    //Stop the animation loop
    cancelAnimationFrame(animationID);
    app.sound.stopBGAudio();
};

function resumeGame() {
    //Stop the animation loop, just in case it's running
    cancelAnimationFrame(animationID);
    paused = false;
    app.sound.playBGAudio();
    //Restart the loop
    update();
};